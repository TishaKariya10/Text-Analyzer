from flask import Flask, render_template, request

app = Flask(__name__)

def analyze_text(text, action):
    if action == "uppercase":
        return text.upper()
    elif action == "lowercase":
        return text.lower()
    elif action == "titlecase":
        return text.title()
    elif action == "firstcapital":
        return text.capitalize()
    elif action == "reverse":
        return text[::-1]
    else:
        return text

@app.route("/", methods=["GET", "POST"])
def index():
    output = ""
    if request.method == "POST":
        text = request.form.get("text")
        action = request.form.get("action")
        output = analyze_text(text, action)

    return render_template("index.html", output=output)

if __name__ == "__main__":
    app.run(debug=True)
